// let i = 0;
// setInterval(() => process.stdout.write(i++ + 'hello\r'), 1500);
setTimeout(() => console.log('Down'), 6000);
setTimeout(() => console.log('Up'), 12000);
setTimeout(() => console.log('Right'), 18000);
setTimeout(() => console.log('Left'), 24000);
