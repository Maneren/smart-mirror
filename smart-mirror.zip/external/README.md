## Rapberry Pi

is folder for PAJ7620U2 gesture senzor code. Copy the folder in pi/home.
Run the code in C by

```
cd ~/RaspberryPi/bcm2835/Gesture
sudo make
sudo ./PAJ7620U2
```
https://www.waveshare.com/wiki/PAJ7620U2_Gesture_Sensor
https://stackoverflow.com/questions/47130270/getting-the-continuous-output-of-another-program-in-a-string-in-node-js
